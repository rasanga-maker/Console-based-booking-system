#Constants
CITIES =["Alvin", "Jamz", "Razi", "Mali", "Zuhar"]
PRICE_MATRIX = {
    "Alvin": [0, 20, 40, 40, 20],
    "Jamz": [20, 0, 20, 40, 40],
    "Razi": [40, 20, 0, 20, 40],
    "Mali": [40, 40, 20, 0, 20],
    "Zuhar": [20, 40, 40, 20, 0]
}
VEHICLE_RATES={"trishaw": 1, "car": 2, "van": 3}



def normalise_city(city: str) -> str:
    return next((c for c in CITIES if c.lower() == city.lower()), city)

def price_list():
    print("\nDropMe Price table(KMD)")
    print(f"{'':<10}",end="")
    for city in CITIES:
        print(f"{city:<10}",end="")
    print("\n"+"-"*60)
    
    for from_city in CITIES:
        print(from_city + " " * (10 - len(from_city)), end="")
        for to_city in CITIES:
            price=PRICE_MATRIX [from_city][CITIES.index(to_city)]
            print(f"{price:<10}",end="")
        print()
    
    print("\nVehicle Multiplier:")
    print("Trishaw: 1x")
    print("Car: 2x (/c)")
    print("Van: 3x (/v)")
    
def help_page():
    print("DropMe Command Help")
    print("\ndm [start] [end]           Calculate trip(Trishaw)")
    print("dm [start] [end] /c        Calculate trip(Car)")
    print("dm [start] [end] /v        Calculate trip(Van)")
    print("dm [start] [end] /pro[]    Add promotion(pro2/pro5/pro10)")
    print("dm /price                  Show price chart")

