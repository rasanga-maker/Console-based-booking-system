import datetime
import random

#invoice text file making part
def making_invoice(start: str, end: str, amount: int, 
                   promo: int, random_discount: int, 
                   final: int) -> str:
    now=datetime.datetime.now()
    time_=now.strftime("%Y-%m-%d %H_%M_%S")
    filename=str(time_)+ "_" +str(random.randint(1000, 9999))+".txt"

    content = "Date : "+now.strftime('%Y-%m-%d') + "\n" + \
              "Time : "+now.strftime('%H:%M:%S') + "\n" + \
              "Start :"+ start + "\n" + \
              "End : "+end + "\n" + \
              "Amount :"+ str(amount) + "KMD\n" + \
              "Promo : " + str(promo) + "KMD\n" + \
              "Random Reduction : " + str(random_discount) + "KMD\n" + \
              "Final payment : " + str(final) + "KMD"

    with open(filename, 'w') as f:
        f.write(content)

    print("\nInvoice generated: " + filename + "\n")
    print(content.replace(" :", ":").replace("KMD", " KMD"))
    return filename
