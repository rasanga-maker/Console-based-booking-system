import sys
import random
from helpPage.helpPage import CITIES,PRICE_MATRIX,VEHICLE_RATES,normalise_city,help_page,price_list
from invoice.invoice import making_invoice

def calculating_trip(args: list):
    try:
        start=normalise_city(args[0])
        end=normalise_city(args[1])
        
        if start not in CITIES or end not in CITIES:
            raise ValueError("Invalid city. Valid options: " + ", ".join(CITIES))

        vehicle="trishaw"
        promo_code=None
        
        for arg in args[2:]:
            arg_lower=arg.lower()
            if arg_lower== "/c":
                vehicle="car"
            elif arg_lower=="/v":
                vehicle="van"
            elif arg_lower.startswith("/pro"):
                promo_code=arg
        
        from_index=CITIES.index(start)
        to_index=CITIES.index(end)
        normal_price=PRICE_MATRIX[start][to_index]

        multiplier=VEHICLE_RATES[vehicle]
        price_vehicle=normal_price*multiplier

        promotion =0
        if promo_code:
            try:
                promotion = int(promo_code.replace("/pro", ""))
                if not (1 <= promotion <= 15):
                    print("\nInvalid promotion code")
                    raise ValueError("Promotion must between 1 and 15 KMD.")

            except:
                promotion =0  

        random_discount=0
        lucky_draw=random.random()
        if lucky_draw < 0.2:
            random_discount = 5


        final_price=price_vehicle-promotion -random_discount
        if final_price < 0:
            final_price = 0
        
        making_invoice(
            start,end,price_vehicle, 
            promotion,random_discount,final_price
        )
        
    except Exception as e:
        print("\nError: " + str(e))
        help_page()

#main program part
def main():
    if len(sys.argv)<2:
        help_page()
        return
    
    if sys.argv[1].lower()=="/price":
        price_list()
    elif len(sys.argv)>=3:
        calculating_trip(sys.argv[1:])
    else:
        print("Invalid command")
        help_page()

if __name__=="__main__":
    main()
